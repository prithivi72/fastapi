from pydantic import BaseModel


class Student(BaseModel):
    id: int
    name: str
    course: str
    price: float
    section: str


class Email(BaseModel):
    rec_email: str
    subject: str
    body: str
