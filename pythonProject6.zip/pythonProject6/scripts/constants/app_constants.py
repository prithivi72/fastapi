class API:
    get_item = "/get course"
    post_item = "/post course"
    update_item = "/update course"
    delete_item = "/delete course"
    send_email = "/sending_email"
    Total_price = "/Total_price"


class Db_database:
    db_uri = "mongodb://intern_23:intern%40123@192.168.0.220:2717/interns_b2_23"
    db_name = "interns_b2_23"
    db_collection = "Prithiviraj_course"
